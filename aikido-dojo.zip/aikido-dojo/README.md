# 合気道 · Aïkido Dojo Provence

Site web du club d'aïkido de Provence — La Voie de l'Harmonie.

## Structure du projet

```
aikido-dojo/
├── index.html              # Page d'accueil (one-page complète)
├── css/
│   ├── tokens.css          # Variables design system (couleurs, typo, spacing)
│   ├── base.css            # Reset, typographie, grilles utilitaires
│   ├── components.css      # Nav, boutons, cards, formulaires, FAQ, lightbox
│   └── sections.css        # Hero, about, cours, galerie, agenda, footer…
├── js/
│   ├── main.js             # Nav scroll, thème, hamburger, scroll reveal, parallax, toast
│   ├── gallery.js          # Lightbox (↔ clavier, Esc), filtres galerie
│   └── ui.js               # FAQ accordion, formulaires, newsletter, recherche, agenda
├── pages/
│   ├── about.html          # Histoire, philosophie, valeurs, biographies
│   ├── cours.html          # Planning, tarifs, premier cours, FAQ complète
│   ├── actualites.html     # Blog avec filtres catégories et sidebar
│   ├── ressources.html     # Bibliothèque, recherche, glossaire japonais
│   └── contact.html        # Formulaire, 3 dojos détaillés, réseaux sociaux
├── vercel.json             # Déploiement Vercel (URL propres, cache, sécurité)
├── .gitignore
└── README.md
```

## Design system

| Token | Valeur | Usage |
|-------|--------|-------|
| `--sumi` | `#0a0a0a` | Fond sombre, texte principal |
| `--washi` | `#f8f5f0` | Fond clair, papier washi |
| `--torii` | `#8b1a1a` | Accent principal (rouge torii) |
| `--gold` | `#c8a96a` | Accent secondaire (laque dorée) |
| `--bamboo` | `#2d4a35` | Accent tertiaire (vert bambou) |

**Typographies :**
- Display : `Cormorant Garamond` (serif, poids 300–400)
- Corps : `Inter` (sans-serif, poids 300–600)
- Japonais : `Noto Serif JP`

**Signature visuelle :** Enso SVG animé en stroke-dashoffset dans le hero

## Fonctionnalités

- **Navigation** fixe avec scroll detection, mode sombre/clair (localStorage), hamburger mobile
- **Scroll reveal** via IntersectionObserver
- **Parallax** sur l'Enso du hero
- **Galerie** avec lightbox (navigation clavier ← →, fermeture Esc/backdrop), filtres catégorie
- **FAQ accordion** (un seul item ouvert à la fois)
- **Planning** cliquable avec toast notifications
- **Formulaire contact** avec validation et feedback
- **Newsletter** avec validation email
- **Marquee témoignages** infini (pause au hover)
- **Blog** avec filtres côté client
- **Recherche** live sur les ressources
- **Agenda** avec inscriptions
- SEO : meta description, OG tags, canonical, aria-labels, WCAG

## Déploiement

### Vercel (recommandé)

```bash
# 1. Installer Vercel CLI
npm i -g vercel

# 2. Déployer
cd aikido-dojo
vercel

# 3. Pour la production
vercel --prod
```

Ou glisser-déposer le dossier sur [vercel.com/new](https://vercel.com/new).

### GitHub Pages

```bash
# 1. Créer un repo GitHub
git init
git add .
git commit -m "Initial commit — Aïkido Dojo Provence"
git branch -M main
git remote add origin https://github.com/votre-user/aikido-dojo.git
git push -u origin main

# 2. Dans Settings > Pages > Source : Deploy from branch > main / (root)
```

### Local

Ouvrir simplement `index.html` dans un navigateur — aucun serveur requis.  
Pour un serveur local :

```bash
npx serve .
# ou
python3 -m http.server 3000
```

## Personnalisation

### Remplacer les images

Les images viennent d'Unsplash (chargement externe). Pour utiliser vos propres photos :
1. Placer les images dans `/assets/images/`
2. Remplacer les URLs `https://images.unsplash.com/...` dans les HTML

### Mettre à jour le contenu

- **Planning** → `index.html` section `#cours` et `pages/cours.html`
- **Tarifs** → même fichiers
- **Agenda** → section `#agenda` dans `index.html`
- **Enseignants** → `pages/about.html`
- **Contact** → `pages/contact.html` et section `#contact` dans `index.html`

### Couleurs

Modifier les variables dans `css/tokens.css` section `:root`.

### Mode sombre

Modifier les valeurs dans `[data-theme="dark"]` dans `css/tokens.css`.

## Affiliations

- FFAB — Fédération Française d'Aïkido et de Budo
- CID Provence — Comité Interrégional de Développement

---

*Site réalisé pour le Club d'Aïkido de Provence · 合気道 · La voie de l'harmonie*
