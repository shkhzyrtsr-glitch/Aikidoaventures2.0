/**
 * GALLERY.JS — Lightbox & filtres galerie
 * Aïkido Dojo Provence
 */

'use strict';

/* ═══════════════════════════════════════════
   LIGHTBOX
═══════════════════════════════════════════ */
(function initLightbox() {
  // Create lightbox DOM if absent
  let lightbox = document.getElementById('lightbox');

  if (!lightbox) {
    lightbox = document.createElement('div');
    lightbox.id = 'lightbox';
    lightbox.className = 'lightbox';
    lightbox.innerHTML = `
      <button class="lightbox__close" aria-label="Fermer">✕</button>
      <img id="lightboxImg" src="" alt="Image agrandie">
    `;
    document.body.appendChild(lightbox);
  }

  const img = document.getElementById('lightboxImg');
  const closeBtn = lightbox.querySelector('.lightbox__close');

  // Collect all gallery items
  const items = document.querySelectorAll('.galerie__item');
  let currentIndex = 0;

  items.forEach((item, index) => {
    item.addEventListener('click', () => openLightbox(item, index));

    // Add keyboard support
    item.setAttribute('tabindex', '0');
    item.setAttribute('role', 'button');
    item.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') openLightbox(item, index);
    });
  });

  function openLightbox(item, index) {
    const itemImg = item.querySelector('img');
    if (!itemImg) return;

    currentIndex = index;
    img.src = itemImg.src.replace(/w=\d+/, 'w=1200'); // upscale for lightbox
    img.alt = itemImg.alt || 'Galerie aïkido';

    lightbox.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closeLightbox() {
    lightbox.classList.remove('open');
    document.body.style.overflow = '';
    img.src = '';
  }

  function navigate(direction) {
    const activeItems = Array.from(items).filter(
      item => !item.classList.contains('hidden')
    );
    const activeIndex = activeItems.indexOf(items[currentIndex]);
    const nextActive = (activeIndex + direction + activeItems.length) % activeItems.length;
    const nextItem = activeItems[nextActive];
    const nextItemGlobal = Array.from(items).indexOf(nextActive);
    openLightbox(nextItem, nextItemGlobal >= 0 ? nextItemGlobal : activeIndex);
  }

  // Close on backdrop click
  lightbox.addEventListener('click', e => {
    if (e.target === lightbox) closeLightbox();
  });

  closeBtn.addEventListener('click', closeLightbox);

  // Keyboard navigation
  document.addEventListener('keydown', e => {
    if (!lightbox.classList.contains('open')) return;
    if (e.key === 'Escape')    closeLightbox();
    if (e.key === 'ArrowRight') navigate(1);
    if (e.key === 'ArrowLeft')  navigate(-1);
  });

  // Expose for inline use
  window.openLightbox  = (item) => {
    const idx = Array.from(items).indexOf(item);
    openLightbox(item, idx >= 0 ? idx : 0);
  };
  window.closeLightbox = closeLightbox;
})();

/* ═══════════════════════════════════════════
   GALLERY FILTER
═══════════════════════════════════════════ */
(function initGalleryFilter() {
  const filterBtns = document.querySelectorAll('.filter-btn');
  const galleryItems = document.querySelectorAll('.galerie__item');

  if (!filterBtns.length) return;

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      // Update active state
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filter = btn.dataset.filter || btn.textContent.trim().toLowerCase();

      galleryItems.forEach(item => {
        const category = item.dataset.category || '';
        const show = filter === 'tout' || filter === 'all' || !filter || category.includes(filter);

        if (show) {
          item.classList.remove('hidden');
          item.style.display = '';
        } else {
          item.classList.add('hidden');
          item.style.display = 'none';
        }
      });
    });
  });
})();

/* ═══════════════════════════════════════════
   ALBUMS GRID — responsive column layout
═══════════════════════════════════════════ */
(function initAlbumsLayout() {
  const grid = document.querySelector('.galerie__grid');
  if (!grid) return;

  function adjustLayout() {
    const w = window.innerWidth;
    if (w < 768) {
      grid.style.gridTemplateColumns = 'repeat(2, 1fr)';
      grid.style.gridAutoRows = '160px';
    } else if (w < 1024) {
      grid.style.gridTemplateColumns = 'repeat(3, 1fr)';
      grid.style.gridAutoRows = '180px';
    } else {
      grid.style.gridTemplateColumns = '';
      grid.style.gridAutoRows = '';
    }
  }

  window.addEventListener('resize', adjustLayout, { passive: true });
  adjustLayout();
})();
