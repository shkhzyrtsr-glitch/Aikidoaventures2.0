/**
 * MAIN.JS — Initialisation, navigation, thème, scroll
 * Aïkido Dojo Provence
 */

'use strict';

/* ═══════════════════════════════════════════
   NAVIGATION — scroll behaviour
═══════════════════════════════════════════ */
(function initNav() {
  const nav = document.getElementById('mainNav');
  if (!nav) return;

  function updateNav() {
    nav.classList.toggle('scrolled', window.scrollY > 40);
  }

  window.addEventListener('scroll', updateNav, { passive: true });
  updateNav();
})();

/* ═══════════════════════════════════════════
   ACTIVE NAV LINK — highlight current section
═══════════════════════════════════════════ */
(function initActiveLinks() {
  const sections = document.querySelectorAll('section[id], div[id]');
  const navLinks = document.querySelectorAll('.nav__links a[href^="#"]');

  if (!sections.length || !navLinks.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.id;
        navLinks.forEach(link => {
          link.classList.toggle('active', link.getAttribute('href') === '#' + id);
        });
      }
    });
  }, { threshold: 0.3 });

  sections.forEach(s => observer.observe(s));
})();

/* ═══════════════════════════════════════════
   THEME TOGGLE — clair / sombre
═══════════════════════════════════════════ */
(function initTheme() {
  const btn = document.getElementById('themeToggle');
  if (!btn) return;

  const stored = localStorage.getItem('aikido-theme');
  if (stored === 'dark') {
    document.documentElement.dataset.theme = 'dark';
    btn.textContent = '☀';
  }

  btn.addEventListener('click', () => {
    const isDark = document.documentElement.dataset.theme === 'dark';
    const next = isDark ? '' : 'dark';
    document.documentElement.dataset.theme = next;
    btn.textContent = isDark ? '☽' : '☀';
    localStorage.setItem('aikido-theme', next || 'light');
  });
})();

/* ═══════════════════════════════════════════
   HAMBURGER — menu mobile
═══════════════════════════════════════════ */
(function initMobileMenu() {
  const btn = document.getElementById('hamburgerBtn');
  const menu = document.getElementById('mobileMenu');
  if (!btn || !menu) return;

  btn.addEventListener('click', () => {
    const isOpen = menu.classList.toggle('open');
    btn.classList.toggle('open', isOpen);
    document.body.style.overflow = isOpen ? 'hidden' : '';
  });

  // Close on link click
  menu.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', closeMobileMenu);
  });

  function closeMobileMenu() {
    menu.classList.remove('open');
    btn.classList.remove('open');
    document.body.style.overflow = '';
  }

  // Expose globally for inline onclick attributes
  window.closeMobile = closeMobileMenu;
})();

/* ═══════════════════════════════════════════
   SCROLL REVEAL — IntersectionObserver
═══════════════════════════════════════════ */
(function initReveal() {
  const elements = document.querySelectorAll('.reveal');
  if (!elements.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target); // only once
      }
    });
  }, {
    threshold: 0.08,
    rootMargin: '0px 0px -40px 0px'
  });

  elements.forEach(el => observer.observe(el));
})();

/* ═══════════════════════════════════════════
   PARALLAX — Enso hero
═══════════════════════════════════════════ */
(function initParallax() {
  const enso = document.querySelector('.hero__enso');
  if (!enso) return;

  window.addEventListener('scroll', () => {
    const y = window.scrollY * 0.15;
    enso.style.transform = `translateY(calc(-50% + ${y}px))`;
  }, { passive: true });
})();

/* ═══════════════════════════════════════════
   TOAST — utilitaire
═══════════════════════════════════════════ */
function showToast(message, duration = 3500) {
  let toast = document.getElementById('globalToast');

  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'globalToast';
    toast.className = 'toast';
    document.body.appendChild(toast);
  }

  toast.textContent = message;
  toast.classList.add('show');

  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => {
    toast.classList.remove('show');
  }, duration);
}

window.showToast = showToast;

/* ═══════════════════════════════════════════
   SMOOTH ANCHOR — pad for fixed nav
═══════════════════════════════════════════ */
document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener('click', e => {
    const target = document.querySelector(link.getAttribute('href'));
    if (!target) return;
    e.preventDefault();
    const navH = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--nav-h')) || 68;
    const top = target.getBoundingClientRect().top + window.scrollY - navH;
    window.scrollTo({ top, behavior: 'smooth' });
  });
});
