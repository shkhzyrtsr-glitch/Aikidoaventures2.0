/**
 * UI.JS — FAQ, planning, formulaires, recherche, agenda
 * Aïkido Dojo Provence
 */

'use strict';

/* ═══════════════════════════════════════════
   FAQ ACCORDION
═══════════════════════════════════════════ */
(function initFaq() {
  const questions = document.querySelectorAll('.faq__question');
  if (!questions.length) return;

  questions.forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.closest('.faq__item');
      const isOpen = item.classList.contains('open');

      // Close all
      document.querySelectorAll('.faq__item.open').forEach(i => i.classList.remove('open'));

      // Open clicked (toggle)
      if (!isOpen) item.classList.add('open');
    });
  });
})();

/* ═══════════════════════════════════════════
   CONTACT FORM
═══════════════════════════════════════════ */
(function initContactForm() {
  const form = document.getElementById('contactForm');
  if (!form) return;

  form.addEventListener('submit', e => {
    e.preventDefault();
    handleContactSubmit();
  });

  // Also handle btn click (for non-form buttons)
  const submitBtn = document.getElementById('contactSubmit');
  if (submitBtn) submitBtn.addEventListener('click', handleContactSubmit);
})();

function handleContactSubmit() {
  const nameEl  = document.getElementById('f-name');
  const emailEl = document.getElementById('f-email');
  const msgEl   = document.getElementById('f-msg');

  if (!nameEl || !emailEl || !msgEl) return;

  const name  = nameEl.value.trim();
  const email = emailEl.value.trim();
  const msg   = msgEl.value.trim();

  if (!name) { showFieldError(nameEl, 'Veuillez saisir votre nom.'); return; }
  if (!validateEmail(email)) { showFieldError(emailEl, 'Adresse email invalide.'); return; }
  if (!msg)  { showFieldError(msgEl, 'Veuillez saisir un message.'); return; }

  // Simulate send
  window.showToast?.(`Merci ${name} ! Votre message a été envoyé. Nous répondons sous 24h.`);

  // Reset
  nameEl.value = '';
  emailEl.value = '';
  msgEl.value = '';
}

function showFieldError(el, msg) {
  el.style.borderColor = 'var(--torii-2)';
  el.focus();
  setTimeout(() => el.style.borderColor = '', 2000);
  window.showToast?.(msg);
}

function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/* ═══════════════════════════════════════════
   ESSAI FORM (rapide, hero ou contact)
═══════════════════════════════════════════ */
(function initEssaiForm() {
  const btn = document.getElementById('essaiBtn');
  if (!btn) return;

  btn.addEventListener('click', () => {
    const section = document.getElementById('contact');
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
      // Pre-select option
      const select = document.getElementById('f-sujet');
      if (select) select.value = 'Réserver un cours d\'essai';
    }
  });
})();

/* ═══════════════════════════════════════════
   NEWSLETTER
═══════════════════════════════════════════ */
(function initNewsletter() {
  const forms = document.querySelectorAll('.newsletter-form');

  forms.forEach(form => {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const input = form.querySelector('input[type="email"]');
      if (!input) return;

      const email = input.value.trim();
      if (!validateEmail(email)) {
        window.showToast?.('Veuillez saisir une adresse email valide.');
        return;
      }

      window.showToast?.('✓ Inscription confirmée ! Vous recevrez bientôt notre lettre du dojo.');
      input.value = '';
    });
  });
})();

/* ═══════════════════════════════════════════
   SEARCH — bibliothèque ressources
═══════════════════════════════════════════ */
(function initSearch() {
  const input = document.getElementById('searchInput');
  const btn   = document.getElementById('searchBtn');
  const cards = document.querySelectorAll('.card--res');

  if (!input) return;

  function doSearch() {
    const q = input.value.trim().toLowerCase();
    if (!q) {
      cards.forEach(c => c.style.display = '');
      return;
    }

    let found = 0;
    cards.forEach(card => {
      const text = card.textContent.toLowerCase();
      const match = text.includes(q);
      card.style.display = match ? '' : 'none';
      if (match) found++;
    });

    if (found === 0) {
      window.showToast?.(`Aucun résultat pour « ${q} »`);
    }
  }

  btn?.addEventListener('click', doSearch);
  input.addEventListener('keydown', e => { if (e.key === 'Enter') doSearch(); });

  // Live filter
  input.addEventListener('input', () => {
    if (!input.value.trim()) cards.forEach(c => c.style.display = '');
  });
})();

/* ═══════════════════════════════════════════
   AGENDA — inscription
═══════════════════════════════════════════ */
(function initAgenda() {
  document.querySelectorAll('.agenda__register').forEach(btn => {
    btn.addEventListener('click', () => {
      const item  = btn.closest('.agenda__item');
      const title = item?.querySelector('.agenda__title')?.textContent || 'cet événement';
      window.showToast?.(`Inscription enregistrée pour : ${title}`);
    });
  });
})();

/* ═══════════════════════════════════════════
   PLANNING SLOT — tooltip / detail
═══════════════════════════════════════════ */
(function initPlanning() {
  document.querySelectorAll('.planning__slot').forEach(slot => {
    slot.addEventListener('click', () => {
      const time  = slot.querySelector('.slot__time')?.textContent || '';
      const label = slot.querySelector('.slot__label')?.textContent || '';
      window.showToast?.(`🥋 ${time} — ${label}`);
    });
  });
})();

/* ═══════════════════════════════════════════
   COUNTER ANIMATION — hero stats
═══════════════════════════════════════════ */
(function initCounters() {
  const counters = document.querySelectorAll('[data-count]');
  if (!counters.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el  = entry.target;
      const end = parseInt(el.dataset.count);
      const dur = 1800;
      const step = Math.ceil(end / (dur / 16));
      let current = 0;

      const timer = setInterval(() => {
        current = Math.min(current + step, end);
        el.textContent = current.toLocaleString('fr');
        if (current >= end) clearInterval(timer);
      }, 16);

      observer.unobserve(el);
    });
  }, { threshold: 0.5 });

  counters.forEach(el => observer.observe(el));
})();

/* ═══════════════════════════════════════════
   BLOG SHARE
═══════════════════════════════════════════ */
(function initBlogShare() {
  document.querySelectorAll('.share-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const network = btn.dataset.network;
      const url     = encodeURIComponent(window.location.href);
      const title   = encodeURIComponent(document.title);

      const urls = {
        facebook:  `https://www.facebook.com/sharer/sharer.php?u=${url}`,
        twitter:   `https://twitter.com/intent/tweet?url=${url}&text=${title}`,
        linkedin:  `https://www.linkedin.com/shareArticle?url=${url}&title=${title}`,
        whatsapp:  `https://api.whatsapp.com/send?text=${title}%20${url}`,
      };

      if (urls[network]) {
        window.open(urls[network], '_blank', 'width=600,height=450');
      }
    });
  });
})();
